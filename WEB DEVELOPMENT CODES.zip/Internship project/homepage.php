<?php
 include 'app/connect.php';
?>
<!DOCTYPE html>
<html>
<head>

    <title>Automobile stockbroking site</title>
    <link rel="stylesheet" href="assets/homepage.css">
	
    <style>
     body{
     background-image:url("1.jpg");
     background-repeat:no-repeat;
     background-size:cover;
      }
     </style>    

</head>
<body>
     <div class="main">
          <div class="navbar">
               <div class="icon">
                    <h2 class="logo">Project</h2>
               </div>
               <div class="menu">
                    <ul>
                         <li><a href="#">HOME</a></li>
                         <li><a href="about.php">ABOUT</a></li>
                         <li><a href="adminlogin.php">ADMIN</a></li>
                         <li><a href="user.php">USER</a></li>
                         <li><a href="contact.php">CONTACT</a></li>
                    </ul>
               </div> 
          </div>
          <div class="content">
           <center>
               <h1>Automobile<br><span>Stockbroking</span><br>Platform</h1>
               <p class="par">Hi,you are at the right palce at right time .Select ypur dream vehicle as a part of your<br>
                              family and have a good journey. To know about vehicle and select your<br>
                              dream vehicle .Please register and login.
               </p>
           </center>    
          </div>
     </div>

</body>
</html>