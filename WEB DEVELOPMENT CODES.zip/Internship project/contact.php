<?php
 include 'app/connect.php';
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Contact info</title>
    <style>
    body{
        background: black;
        min-height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
        background-size:cover;
      }
    </style>
    <link rel="stylesheet" href="assets/contact.css">
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.css">
  </head>
  <body>
      <a href="homepage.php" class="homelink">HOME</a>
    <div class="contact-info">
      <div class="card">
        <i class="card-icon far fa-envelope"></i>
        <p>automobilestockbroking@gmail.com</p>
       </div>

      <div class="card">
        <i class="card-icon fas fa-phone"></i>
        <p>+91 7899485898</p>
       </div>

      <div class="card">
        <i class="card-icon fas fa-map-marker-alt"></i>
        <p>Kundapura, Karnataka</p>
      </div>
    </div>
     
  </body>
</html>
 


 